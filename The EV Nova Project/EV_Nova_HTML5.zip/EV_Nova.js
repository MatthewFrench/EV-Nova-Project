/**
  EV Nova Code
*/

var loadImages = 0;
var loadCount = 0;
var playerImg = new Array(26);
var playerLeft = new Array(26);
var playerRight = new Array(26);
var propulsionStraight = new Array(16);
var propulsionLeft = new Array(16);
var propulsionRight = new Array(16);

var propulsion;
var propulsionAnim = -1;
var propulsionAnimCount = 0;

var hudImg = new Image();

var player;
var playerAnim = 0;
var playerAnimCount = 0;

var test;

var playerX = 50;
var playerY = 50;

var playerVelX = 0;
var playerVelY = 0;
var playerAccel = 0.1;
var playerTopVel = 2;
var playerSlowFactor = 0.9;

var playerRotation = 0;
var playerRotationSpeed = 2.0;

var playerArmor = 25;
var playerShield = 50;
var playerEnergy = 75;

var up = false;
var down = false;
var left = false;
var right = false;
var spaceBar = false;

var solarSystemRadius = 3000;
var starArray = new Array();

var redraw = false;
var redrawHud = false;
var redrawCount = 0;

var startTickTime;
var endTickTime;
var delta;
var hudCanvas = document.getElementById("hudCanvas");
var hudCtx = hudCanvas.getContext("2d");
var gameCanvas = document.getElementById("mainCanvas");
var gameCtx = gameCanvas.getContext("2d");

var mapXOrigin = 10;
var mapYOrigin = 10;
var mapXSize = 175;
var mapYSize = 175;


var redrawStart;
var redrawEnd;
var delta;

function initialize() {
	if (loadImages == 0) {
		//Make the star map
		for (i = 0; i < 1000; i++) {
			starArray[i] = [(Math.random()* solarSystemRadius*2)-solarSystemRadius,(Math.random()* solarSystemRadius*2)-solarSystemRadius];
		}
		
		var animFrames = 26;

		//Double array, rotation, then animation
		for (e = 0; e < animFrames; e++) {
			playerImg[e] = new Image();
			var num = "00" + e;
			if (e < 10) {num = "000"+e}
			playerImg[e].src = "Ship Gfx/Dark Flier/Ship/Straight"+"_"+num+".png";
			playerImg[e].onload = function() {
        			loadImages += 1;
				initialize();
    			}
			loadCount += 1;
		}
		for (e = 0; e < animFrames; e++) {
			playerLeft[e] = new Image();
			var num = "00" + e;
			if (e < 10) {num = "000"+e}
			playerLeft[e].src = "Ship Gfx/Dark Flier/Ship/Left"+"_"+num+".png";
			playerLeft[e].onload = function() {
        			loadImages += 1;
				initialize();
    			}
			loadCount += 1;
		}
		for (e = 0; e < animFrames; e++) {
			playerRight[e] = new Image();
			var num = "00" + e;
			if (e < 10) {num = "000"+e}
			playerRight[e].src = "Ship Gfx/Dark Flier/Ship/Right"+"_"+num+".png";
			playerRight[e].onload = function() {
        			loadImages += 1;
				initialize();
    			}
			loadCount += 1;
		}
			

		for (e = 50; e < 66; e++) {
			propulsionStraight[e-50] = new Image();
			var num = "00" + e;
			if (e < 10) {num = "000"+e}
			propulsionStraight[e-50].src = "Ship Gfx/Dark Flier/Propulsion/Straight"+"_"+num+".png";
			propulsionStraight[e-50].onload = function() {
        			loadImages += 1;
				initialize();
    			}
			loadCount += 1;
		}
		for (e = 50; e < 66; e++) {
			propulsionLeft[e-50] = new Image();
			var num = "00" + e;
			if (e < 10) {num = "000"+e}
			propulsionLeft[e-50].src = "Ship Gfx/Dark Flier/Propulsion/Left"+"_"+num+".png";
			propulsionLeft[e-50].onload = function() {
        			loadImages += 1;
				initialize();
    			}
			loadCount += 1;
		}
		for (e = 50; e < 66; e++) {
			propulsionRight[e-50] = new Image();
			var num = "00" + e;
			if (e < 10) {num = "000"+e}
			propulsionRight[e-50].src = "Ship Gfx/Dark Flier/Propulsion/Right"+"_"+num+".png";
			propulsionRight[e-50].onload = function() {
        			loadImages += 1;
				initialize();
    			}
			loadCount += 1;
		}
		

		hudImg.src = "HUD.png";
		hudImg.onload = function() {
        		loadImages += 1;
			initialize();
    		}
		loadCount += 1;
	} else if (loadImages == loadCount) {
		propulsion = propulsionStraight;
		player = playerImg;
		redraw = true;
		redrawHud = true;

		//Start Timer
		gameLogic ();
		scheduleRedraw ();
	}
}

function gameLogic() {
	starTickTime = new Date ().getTime();

	//Player animation
	playerAnimCount += 1;
	if (playerAnimCount > 2) {
		playerAnimCount = 0;
		playerAnim += 1;
		if (playerAnim > 25) {playerAnim = 0;}
	}

	//Propulsion animation
	if (left) {propulsion = propulsionLeft;} //If going left, show left propulsion
	if (right) {propulsion = propulsionRight;} //If going right, show right propulsion
	if ((left && right) || (!left && !right)) {propulsion = propulsionStraight;} //Otherwise show straight propulsion
	//If accelerating
	if (up) {
		if (propulsionAnim == -1) {propulsionAnim = 0;} else {
			propulsionAnim += 1;
			if (propulsionAnim > 15) {propulsionAnim = 10;}
		}
	} else {
		//Not accelerating so slow down until eventual stop
		if (propulsionAnim > 10) {propulsionAnim = 10;} else if (propulsionAnim > -1) {
			propulsionAnim -= 1;
		}
	}


	if (up) {
		//Speeds Up
		var rot = Math.PI * playerRotation / 180;
		var newVelX = playerVelX + (Math.cos(rot)*playerAccel);
		var newVelY = playerVelY + (Math.sin(rot)*playerAccel);
		if (newVelX* newVelX +newVelY* newVelY > playerTopVel* playerTopVel) {
			var theta = Math.atan2(newVelY,newVelX);
			newVelX = (Math.cos(theta)* playerTopVel);
			newVelY = (Math.sin(theta)* playerTopVel);
		}
		playerVelX = newVelX;
		playerVelY = newVelY;
	}
	if (down) {
		//Slows down
		playerVelX *= playerSlowFactor;
		playerVelY *= playerSlowFactor;
		if (Math.abs(playerVelX) < 0.005) {playerVelX = 0;}
		if (Math.abs(playerVelY) < 0.005) {playerVelY = 0;}
	}
	if (left) {playerRotation -= playerRotationSpeed;redraw = true; player = playerLeft;}
	if (right) {playerRotation += playerRotationSpeed;redraw = true; player = playerRight}
	if ((left && right) || (!left && !right)) {player = playerImg; redraw = true;}
	if (playerRotation < 0) {playerRotation += 360;}
	if (playerRotation >= 360) {playerRotation -= 360;}
	if (spaceBar) {
		//Shoot projectiles
		
	}
	playerX += playerVelX;
	playerY += playerVelY;
	var canvas = document.getElementById("mainCanvas");
	if (playerX > solarSystemRadius-canvas.width/2) {playerX = -solarSystemRadius+canvas.width/2;}
	if (playerX < -solarSystemRadius+canvas.width/2) {playerX = solarSystemRadius-canvas.width/2;}
	if (playerY > solarSystemRadius-canvas.height/2) {playerY = -solarSystemRadius+canvas.height/2;}
	if (playerY < -solarSystemRadius+canvas.height/2) {playerY = solarSystemRadius-canvas.height/2;}
	if (playerVelX != 0 || playerVelY != 0) {redraw = true;}
	//redrawCount += 1;

	endTickTime = new Date ().getTime();

	delta = endTickTime  - starTickTime;
	if (16-delta > 0)
		setTimeout(gameLogic, 16-delta);
	else
		gameLogic ();
}

function scheduleRedraw (){
	if (redraw){
		redrawCount = 0;
		redraw = false;
		updateCanvas();
		updateMap();
	}
	if (redrawHud){
		redrawHud = false;
		updateHUD();
	}
	setTimeout(scheduleRedraw, 0);
}

function updateCanvas() {
	gameCtx.fillStyle = "rgb(0, 0, 0)";
	gameCtx.fillRect(0,0,gameCanvas.width,gameCanvas.height)

	var cameraX = playerX + gameCanvas.width/2;
	var cameraY = playerY + gameCanvas.height/2;

	//Draw the stars
	var x;
	var y;
	for (i = 0; i < 1000; i++) {
		x = starArray[i][0] - cameraX + gameCanvas.width;
		y = starArray[i][1] - cameraY + gameCanvas.height;
		if (x > -3 && x < gameCanvas.width+3 && y > -3 && y < gameCanvas.height+3) {
			gameCtx.beginPath();
			gameCtx.arc(x, y, 1.0, 0, 2 * Math.PI, false);
			gameCtx.fillStyle = "rgb(255, 255, 255)";
			gameCtx.fill();
		}
	}

	var rot = playerRotation * Math.PI / 180.0;

	gameCtx.translate(cameraX - playerX, cameraY - playerY);
	gameCtx.rotate(rot);
	gameCtx.drawImage(player[playerAnim], -player[playerAnim].width/2, -player[playerAnim].height/2);

	if (propulsionAnim != -1) {
		gameCtx.drawImage(propulsion[propulsionAnim], -propulsion[propulsionAnim].width/2, -propulsion[propulsionAnim].height/2);
	}

	gameCtx.rotate(-rot);
	gameCtx.translate(-(cameraX -playerX), -(cameraY -playerY));
}

function updateMap (){
	//Draw Map
	hudCtx.clearRect(mapXOrigin, mapYOrigin, mapXSize,mapYSize);
	
	var playerMapX = (playerX+solarSystemRadius)/(solarSystemRadius*2)*mapXSize + mapXOrigin;
	var playerMapY = (playerY+solarSystemRadius)/(solarSystemRadius*2)*mapYSize + mapYOrigin;

	hudCtx.beginPath();
	hudCtx.arc(playerMapX, playerMapY, 2, 0, 2 * Math.PI, false);
	hudCtx.fillStyle = "rgb(0, 255, 255)";
	hudCtx.fill();
}

function updateHUD() {

	hudCtx.drawImage(hudImg, 0, 0);
	
	//Shield Bar
	var lingrad = hudCtx.createLinearGradient(0,188,0,207);
    	lingrad.addColorStop(0.25, 'rgba(250,100,100,0.4)');
	lingrad.addColorStop(0.5, 'rgba(250,0,0,1.0)');
    	lingrad.addColorStop(1, 'rgba(150,0,0,0.8)');
    	hudCtx.fillStyle = lingrad;
	fillRoundedRect(hudCtx, 34,198,(185-34)*playerShield/100,207-198, 4)

	//Armor Bar
	lingrad = hudCtx.createLinearGradient(0,215,0,224);
    	lingrad.addColorStop(0.25, 'rgba(0,50,250,0.8)');
	lingrad.addColorStop(0.5, 'rgba(0,0,250,1.0)');
    	lingrad.addColorStop(1, 'rgba(0,0,150,0.8)');
    	hudCtx.fillStyle = lingrad;
	fillRoundedRect(hudCtx, 34,215,(185-34)*playerArmor/100,224-215, 4)

	//Energy Bar
	var lingrad = hudCtx.createLinearGradient(0,233,0,242);
    	lingrad.addColorStop(0.25, 'rgba(250,250,250,0.8)');
	lingrad.addColorStop(0.5, 'rgba(200,200,200,1.0)');
    	lingrad.addColorStop(1, 'rgba(150,150,150,0.8)');
    	hudCtx.fillStyle = lingrad;
	fillRoundedRect(hudCtx, 34,233,(185-34)*playerEnergy/100,242-233, 4)
}


/////////////////////////
//
// handleKeydown
// - Handles keyboard input.
//
function handleKeydown (ev) {
	key = ( (ev.which) || (ev.keyCode) );
	// Up arrow.
	if (key == 38) {
		up = true;
	}
	// Down arrow.
	if (key == 40) {
		down = true;
	}
	// Left arrow.
	if (key == 37) {
		left = true;
	}
	// Right arrow.
	if (key == 39) {
		right = true;
	}
	//Space bar
	if (key == 32) {
		spaceBat = true;
	}
}
function handleKeyup (ev) {
	key = ( (ev.which) || (ev.keyCode) );
	// Up arrow.
	if (key == 38) {
		up = false;
	}
	// Down arrow.
	if (key == 40) {
		down = false;
	}
	// Left arrow.
	if (key == 37) {
		left = false;
	}
	// Right arrow.
	if (key == 39) {
		right = false;
	}
	//Space bar
	if (key == 32) {
		spaceBat = false;
	}
}

function drawString(ctx, text, posX, posY, textColor, rotation, font, fontSize) {
	var lines = text.split("\n");
	if (!rotation) rotation = 0;
	if (!font) font = "'serif'";
	if (!fontSize) fontSize = 16;
	if (!textColor) textColor = '#000000';
	
    ctx.save();
	ctx.fillStyle = textColor;
    ctx.font = fontSize + "px " + font;
	
    ctx.translate(posX, posY);
	ctx.rotate(rotation * Math.PI / 180);
    ctx.strokeStyle = 'rgb(255,255,255)';
    for (i = 0; i < lines.length; i++) {
        ctx.strokeText(lines[i],0, i*fontSize-1);
        ctx.strokeText(lines[i],0, i*fontSize+1);
        ctx.strokeText(lines[i],-1, i*fontSize);
        ctx.strokeText(lines[i],1, i*fontSize);
        ctx.fillText(lines[i],0, i*fontSize);
	}
	ctx.restore();
}

function fillRoundedRect(ctx, x, y, w, h, r){

        ctx.beginPath();

        ctx.moveTo(x+r, y);

        ctx.lineTo(x+w-r, y);

        ctx.quadraticCurveTo(x+w, y, x+w, y+r);

        ctx.lineTo(x+w, y+h-r);

        ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);

        ctx.lineTo(x+r, y+h);

        ctx.quadraticCurveTo(x, y+h, x, y+h-r);

        ctx.lineTo(x, y+r);

        ctx.quadraticCurveTo(x, y, x+r, y);

        ctx.fill();        

    }

/**/